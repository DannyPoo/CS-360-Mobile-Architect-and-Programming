package com.example.projectforschool;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper  extends SQLiteOpenHelper {

    //User credentials table
    public static final String DATABASE_NAME = "UserCredentials.db";
    public static final int DATABASE_VERSION = 1;
    public static final String USER_TABLE_NAME = "user_credentials";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    private static final String USER_TABLE_CREATE = "CREATE TABLE " + USER_TABLE_NAME + " ("
            + COLUMN_USERNAME + " TEXT PRIMARY KEY, " +
            COLUMN_PASSWORD + " TEXT);";

    //Inventory items table
    public static final String INVENTORY_TABLE_NAME = "inventory";
    public static final String COLUMN_DESCRIPTION = "description";
    public static final String COLUMN_QUANTITY = "quantity";
    public static final String COLUMN_UNIT = "unit";
    private static final String INVENTORY_TABLE_CREATE = "CREATE TABLE " + INVENTORY_TABLE_NAME + " (" +
            COLUMN_DESCRIPTION + " TEXT, " +
            COLUMN_QUANTITY + " INTEGER, " +
            COLUMN_UNIT + " TEXT);";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(USER_TABLE_CREATE);
        System.out.println("DATABASE 1:" + USER_TABLE_CREATE);
        System.out.println("DATABASE 2:" + INVENTORY_TABLE_CREATE);
        db.execSQL(INVENTORY_TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE  IF EXISTS " + USER_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + INVENTORY_TABLE_NAME);
        onCreate(db);
    }
}
