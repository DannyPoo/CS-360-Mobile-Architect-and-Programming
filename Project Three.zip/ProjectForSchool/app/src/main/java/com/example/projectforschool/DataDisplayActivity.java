package com.example.projectforschool;


import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {


    private static final int PERMISSION_SEND_SMS = 123;

    private InventoryManager inventoryManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        System.out.println("test");
        setContentView(R.layout.activity_data_display);

        inventoryManager = new InventoryManager(this);
    }


    public void showAddItemDialog(View view){
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_add_item, null);


        final EditText itemNameEditText = dialogView.findViewById(R.id.editTextItemName);
        final EditText quantityEditText = dialogView.findViewById(R.id.editTextQuantity);
        final EditText unitEditText = dialogView.findViewById(R.id.editTextUnit);
        Button buttonAddItem = dialogView.findViewById(R.id.buttonAddItem);
        Button buttonCancel = dialogView.findViewById(R.id.buttonCancel);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView)
                .setTitle("Add Item");
        final AlertDialog dialog = builder.create();

        buttonAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String itemName = itemNameEditText.getText().toString();
                String quantityStr = quantityEditText.getText().toString();
                String unit = unitEditText.getText().toString();

                int quantity = 0;
                try{
                    quantity = Integer.parseInt(quantityStr);
                }catch (NumberFormatException e) {
                    Toast.makeText(DataDisplayActivity.this, "Invalid integer type",Toast.LENGTH_SHORT).show();
                    return;
                }

                inventoryManager.insertInventoryItem(itemName,quantity,unit);
                addRowToTable(itemName,quantity,unit);

                dialog.dismiss();
            }
        });
        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });

       dialog.show();
    }

    private void addRowToTable(String itemName, int quantity, String unit) {
        TableLayout tableLayout = findViewById(R.id.inventoryTable);
        TableRow newRow = new TableRow(this);
        newRow.setTag(itemName);

        TypedValue outValue = new TypedValue();

        int paddingInPixels = (int) (8 * getResources().getDisplayMetrics().density);

        // Edit Button
        ImageButton editButton = new ImageButton(this);
        editButton.setImageResource(R.drawable.baseline_edit_24);
        getTheme().resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, outValue, true);
        editButton.setBackgroundResource(outValue.resourceId);
        editButton.setContentDescription("Edit");
        getSetOnClickListenerForEditButton(itemName, editButton);
        editButton.setPadding(paddingInPixels,paddingInPixels,paddingInPixels,paddingInPixels);
        newRow.addView(editButton);

        // Item Name TextView
        TextView itemNameTextView = new TextView(this);
        itemNameTextView.setText(itemName);
        itemNameTextView.setGravity(Gravity.CENTER);
        itemNameTextView.setPadding(paddingInPixels,paddingInPixels,paddingInPixels,paddingInPixels);
        newRow.addView(itemNameTextView);

        // Quantity TextView
        TextView quantityTextView = new TextView(this);
        quantityTextView.setText(String.valueOf(quantity));
        quantityTextView.setGravity(Gravity.CENTER);
        quantityTextView.setPadding(paddingInPixels,paddingInPixels,paddingInPixels,paddingInPixels);
        newRow.addView(quantityTextView);

        // Unit TextView
        TextView unitTextView = new TextView(this);
        unitTextView.setText(unit);
        unitTextView.setGravity(Gravity.CENTER);
        unitTextView.setPadding(paddingInPixels,paddingInPixels,paddingInPixels,paddingInPixels);
        newRow.addView(unitTextView);

        // Delete Button
        ImageButton deleteButton = new ImageButton(this);
        deleteButton.setImageResource(R.drawable.baseline_delete_24);
        getTheme().resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, outValue, true);
        deleteButton.setBackgroundResource(outValue.resourceId);
        deleteButton.setContentDescription("Delete");
        deleteButton.setPadding(paddingInPixels,paddingInPixels,paddingInPixels,paddingInPixels);
        getSetOnClickListenerForDeleteButton(itemName, deleteButton);
        newRow.addView(deleteButton);

        tableLayout.addView(newRow);
    }

    private void getSetOnClickListenerForEditButton(String itemName, ImageButton editButton){
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Inflate the AlertDialog layout
                LayoutInflater inflater = LayoutInflater.from(DataDisplayActivity.this);
                View dialogView = inflater.inflate(R.layout.dialog_edit_item, null);

                // Initialize the EditTexts with the item's current details
                EditText editItemName = dialogView.findViewById(R.id.editItemName);
                EditText editItemQuantity = dialogView.findViewById(R.id.editItemQuantity);
                EditText editItemUnit = dialogView.findViewById(R.id.editItemUnit);

                Cursor cursor = inventoryManager.getInventoryItemByDescription(itemName);
                if(cursor != null && cursor.moveToFirst()) {
                    String currentDescription = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COLUMN_DESCRIPTION));
                    int currentQuantity = cursor.getInt(cursor.getColumnIndexOrThrow(DBHelper.COLUMN_QUANTITY));
                    String currentUnit = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COLUMN_UNIT));

                    editItemName.setText(currentDescription);
                    editItemQuantity.setText(String.valueOf(currentQuantity));
                    editItemUnit.setText(currentUnit);
                }
                else{
                    Log.e("EditItem", "Item not found in database: " + itemName);
                }
                if(cursor != null) {
                    cursor.close();
                }
                // Build and show the AlertDialog
                AlertDialog.Builder builder = new AlertDialog.Builder(DataDisplayActivity.this);
                builder.setView(dialogView)
                        .setTitle("Edit Item")
                        .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // Retrieve the updated details from EditTexts
                                String updatedName = editItemName.getText().toString();
                                int updatedQuantity = Integer.parseInt(editItemQuantity.getText().toString());
                                String updatedUnit = editItemUnit.getText().toString();

                                // Update the item in the database
                                inventoryManager.updateInventoryItem(itemName, updatedName, updatedQuantity, updatedUnit);
                                updateTableRow(itemName, updatedName, updatedQuantity, updatedUnit);

                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .create().show();
            }
        });
    }

    private void getSetOnClickListenerForDeleteButton(String itemName, ImageButton deleteButton) {
        TableLayout tableLayout = findViewById(R.id.inventoryTable);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(DataDisplayActivity.this)
                        .setTitle("Delete Item")
                        .setMessage("Are you sure you want to delete this item?")
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Call your delete method here
                                int rowsDeleted = inventoryManager.deleteInventoryItem(itemName);
                                if (rowsDeleted > 0) {
                                    View row = tableLayout.findViewWithTag(itemName);
                                    if(row != null){
                                        tableLayout.removeView(row);
                                    }
                                    Toast.makeText(DataDisplayActivity.this, "Item deleted", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(DataDisplayActivity.this, "Item not found", Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                        .setNegativeButton(android.R.string.no, null)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
            }
        });
    }

    private void updateTableRow(String originalName, String updatedName, int updatedQuantity, String updatedUnit) {
        TableLayout tableLayout = findViewById(R.id.inventoryTable);
        View row = tableLayout.findViewWithTag(originalName);
        if (row != null && row instanceof TableRow) {
            if (originalName.equals(updatedName)) {
                ((TextView)((TableRow) row).getChildAt(1)).setText(updatedName);
                ((TextView)((TableRow) row).getChildAt(2)).setText(String.valueOf(updatedQuantity));
                ((TextView)((TableRow) row).getChildAt(3)).setText(updatedUnit);
                row.setTag(updatedName);
            } else {
                // Replace row
                tableLayout.removeView(row);
                addRowToTable(updatedName, updatedQuantity, updatedUnit);
            }
        }
    }

    public void checkForSMSPermission(View view){
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS},PERMISSION_SEND_SMS);
        }else{
            sendSMSMessage();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == PERMISSION_SEND_SMS){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                sendSMSMessage();
            }else{
                Toast.makeText(this, "SMS permission denied. Cannot send low inventory alerts", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendSMSMessage(){
        List<String> lowInventoryItems = inventoryManager.getLowInventoryItems();
        if(lowInventoryItems.isEmpty()) return;
        String phoneNumber = "1234567890";
        StringBuilder messageBuilder = new StringBuilder("Low inventory alert for: ");
        for (String item : lowInventoryItems){
            messageBuilder.append(item).append(", ");
        }
        String message = messageBuilder.toString().replaceAll("\\s*,\\s*$", "");
        try{
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(getApplicationContext(), "SMS sent.", Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(), "Failed to send SMS.", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

}
