package com.example.projectforschool;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class InventoryManager {

    private DBHelper dbHelper;

    public InventoryManager(Context context){
        dbHelper = new DBHelper(context);
    }

    public long insertInventoryItem(String description, int quantity, String unit){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DBHelper.COLUMN_DESCRIPTION, description);
        values.put(DBHelper.COLUMN_QUANTITY, quantity);
        values.put(DBHelper.COLUMN_UNIT, unit);

        return db.insert(DBHelper.INVENTORY_TABLE_NAME, null, values);
    }

    public List<String> getLowInventoryItems(){
        List<String> lowInventoryItems = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(DBHelper.INVENTORY_TABLE_NAME, new String[]{DBHelper.COLUMN_DESCRIPTION, DBHelper.COLUMN_QUANTITY},null ,null,null,null,null);
        while (cursor.moveToNext()){
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DBHelper.COLUMN_QUANTITY));
            if(quantity < 10){
                String description = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COLUMN_DESCRIPTION));
                lowInventoryItems.add(description);
            }
        }
        cursor.close();

        return lowInventoryItems;
    }

    public Cursor getInventoryItemByDescription(String description){
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        return db.query(DBHelper.INVENTORY_TABLE_NAME, null, DBHelper.COLUMN_DESCRIPTION + " =?", new String[]{description}, null, null, null);
    }

    public Cursor getAllInventoryItems(){
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        return db.query(DBHelper.INVENTORY_TABLE_NAME, null, null, null, null, null, null);
    }

    public int updateInventoryItem(String oldDescription, String newDescription, int newQuantity, String newUnit){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DBHelper.COLUMN_DESCRIPTION, newDescription);
        values.put(DBHelper.COLUMN_QUANTITY, newQuantity);
        values.put(DBHelper.COLUMN_UNIT, newUnit);

        return db.update(DBHelper.INVENTORY_TABLE_NAME, values, DBHelper.COLUMN_DESCRIPTION + " =?", new String[]{oldDescription});
    }

    public int deleteInventoryItem(String description){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        return db.delete(DBHelper.INVENTORY_TABLE_NAME, DBHelper.COLUMN_DESCRIPTION + " =?", new String[]{description});
    }
}
