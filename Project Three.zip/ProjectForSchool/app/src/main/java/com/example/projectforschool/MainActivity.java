package com.example.projectforschool;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText usernameText, passwordText;
    private DBHelper dbHelper;
    private UserManager userManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(this);
        userManager = new UserManager(this);

        usernameText = findViewById(R.id.username);
        passwordText = findViewById(R.id.password);
    }

    public void loginClicked(View view){
        String username = usernameText.getText().toString();
        String password = passwordText.getText().toString();

        if(isValidLogin(username, password)) {
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
            startActivity(intent);
        } else{
            Toast.makeText(this, "Invalid Login. Create a new account", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidLogin(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {DBHelper.COLUMN_USERNAME, DBHelper.COLUMN_PASSWORD};
        String selection = DBHelper.COLUMN_USERNAME + " = ? AND " + DBHelper.COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(
                DBHelper.USER_TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    public void createAccountClicked(View view){
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_create_account, null);

        final EditText editTextUsername = dialogView.findViewById(R.id.editTextUsername);
        final EditText editTextPassword = dialogView.findViewById(R.id.editTextPassword);
        Button buttonCreate = dialogView.findViewById(R.id.buttonCreate);
        Button buttonCancel = dialogView.findViewById(R.id.buttonCancel);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView)
                .setTitle("Create Account");

        final AlertDialog dialog = builder.create();

        buttonCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                String newUsername = editTextUsername.getText().toString();
                String newPassword = editTextPassword.getText().toString();

                if(!newUsername.isEmpty() && !newPassword.isEmpty()){
                    boolean isUserCreated = userManager.createUser(newUsername, newPassword);

                    if(isUserCreated){
                        Toast.makeText(MainActivity.this, "Account created!", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Failed to create the account.!", Toast.LENGTH_SHORT).show();
                    }

                    dialog.dismiss();
                } else{
                    Toast.makeText(MainActivity.this, "Username and password cannot be empty.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }
}