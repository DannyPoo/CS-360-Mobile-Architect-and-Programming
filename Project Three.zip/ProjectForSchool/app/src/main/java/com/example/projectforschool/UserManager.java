package com.example.projectforschool;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;


public class UserManager {
    private DBHelper dbHelper;

    public UserManager(Context context){
        dbHelper = new DBHelper(context);
    }

    public boolean createUser(String username, String password){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DBHelper.COLUMN_USERNAME, username);
        values.put(DBHelper.COLUMN_PASSWORD, password);

        long newRowId = db.insert(DBHelper.USER_TABLE_NAME, null, values);
        return newRowId != -1;
    }

}
